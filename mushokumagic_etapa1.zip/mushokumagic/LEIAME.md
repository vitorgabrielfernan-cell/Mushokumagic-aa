# Mushoku Magic — Etapa 1 (Forge 1.20.1)

Mod de magia inspirado em *Mushoku Tensei: Jobless Reincarnation*.

## O que já funciona nesta etapa
- Sistema de **mana** por jogador (Capability do Forge), com regeneração passiva e sincronização para o cliente a cada 0,5s (base para a GUI futura).
- **Cajado de Água** (`water_staff`) — clique direito lança **Water Ball**:
  - Custa 8 de mana, cooldown de 1 segundo.
  - Dano real por raytrace no primeiro alvo atingido.
  - Partículas de água/bolhas ao longo da trajetória.
  - Som de impacto.
  - Mensagens de erro (sem mana / em recarga) traduzidas em pt-BR e en-US.
- Projeto Gradle completo e pronto para compilar.

## O que ainda NÃO está nesta etapa (vem nas próximas)
Fogo, Terra, Vento, Cura, Elétrica, personagens como entidades (Roxy, Eris, Sylphiette, Ruijerd, Orsted), mundo/estruturas, GUI de habilidades, progressão. Consulte o plano de etapas enviado no chat.

## Sobre a textura
`assets/mushokumagic/textures/item/water_staff.png` é um **placeholder gerado por código** (cajado marrom + esfera azul), só para o item aparecer no jogo. Substitua por uma arte real fiel ao anime quando quiser — o mod não exige mudar nenhum código para isso.

## Como compilar
1. Instale o **JDK 17**.
2. Extraia o ZIP.
3. No terminal, dentro da pasta do projeto:
   - Linux/Mac: `./gradlew build`
   - Windows: `gradlew.bat build`
4. Na primeira execução o Gradle baixa o ForgeGradle e as dependências do Forge 47.2.20 (precisa de internet). Isso pode demorar alguns minutos.
5. O `.jar` final fica em `build/libs/mushokumagic-1.0.0-etapa1.jar`.
6. Para testar sem empacotar: `./gradlew runClient`.

> Este ZIP não inclui os wrappers `gradlew`/`gradlew.bat` nem a pasta `gradle/wrapper` (são binários). Se seu Gradle local não gerar o wrapper automaticamente, rode `gradle wrapper --gradle-version 8.1` uma vez dentro da pasta antes do passo 3.

## Instalação no jogo
Coloque o `.jar` compilado na pasta `mods` de uma instalação com **Forge 47.2.20** para Minecraft **1.20.1**.
