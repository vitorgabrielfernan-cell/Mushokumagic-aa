package com.mushokumagic.item;

import com.mushokumagic.magic.ManaCapabilities;
import com.mushokumagic.magic.spell.Spell;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.List;
import java.util.function.Supplier;

/**
 * Cajado de combate, arma base de Rudeus e Roxy no anime. Ao usar o item, lanca o
 * feitico configurado via spellSupplier (ex: Water Ball) se houver mana suficiente.
 */
public class StaffItem extends Item {

    private final Supplier<Spell> spellSupplier;

    public StaffItem(Properties properties, Supplier<Spell> spellSupplier) {
        super(properties);
        this.spellSupplier = spellSupplier;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) {
            return InteractionResultHolder.pass(stack);
        }

        Spell spell = spellSupplier.get();
        boolean cast = player.getCapability(ManaCapabilities.MANA)
                .map(mana -> spell.tryCast(level, player, mana))
                .orElse(false);

        if (cast) {
            return InteractionResultHolder.success(stack);
        }
        player.displayClientMessage(Component.translatable("message.mushokumagic.not_enough_mana"), true);
        return InteractionResultHolder.fail(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, net.minecraft.world.item.TooltipFlag flag) {
        tooltip.add(Component.translatable("item.mushokumagic.staff.tooltip"));
    }
}
