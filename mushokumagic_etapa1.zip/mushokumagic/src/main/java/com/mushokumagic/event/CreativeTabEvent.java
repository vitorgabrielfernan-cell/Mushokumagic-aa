package com.mushokumagic.event;

import com.mushokumagic.MushokuMagicMod;
import com.mushokumagic.registry.ModItems;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.CreativeModeTabEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Adiciona os itens do mod a abas de criativo ja existentes do jogo.
 * Nas proximas etapas uma aba propria "Mushoku Magic" sera criada.
 */
@Mod.EventBusSubscriber(modid = MushokuMagicMod.MOD_ID)
public class CreativeTabEvent {

    @SubscribeEvent
    public static void onBuildContents(CreativeModeTabEvent.BuildContents event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(ModItems.WATER_STAFF);
        }
    }
}
