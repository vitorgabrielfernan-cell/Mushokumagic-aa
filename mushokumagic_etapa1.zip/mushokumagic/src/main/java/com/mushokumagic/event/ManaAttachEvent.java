package com.mushokumagic.event;

import com.mushokumagic.MushokuMagicMod;
import com.mushokumagic.magic.IManaStorage;
import com.mushokumagic.magic.ManaCapabilities;
import com.mushokumagic.magic.ManaCapabilityProvider;
import com.mushokumagic.network.ManaSyncPacket;
import com.mushokumagic.network.NetworkHandler;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

/**
 * Anexa a capability de mana a todo jogador e cuida da regeneracao passiva
 * e da persistencia da mana entre mortes/respawn.
 */
public class ManaAttachEvent {

    public static final ResourceLocation MANA_CAPABILITY_ID =
            new ResourceLocation(MushokuMagicMod.MOD_ID, "mana");

    private static final float PASSIVE_REGEN_PER_TICK = 0.02f;

    @SubscribeEvent
    public void onAttachCapabilities(AttachCapabilitiesEvent<net.minecraft.world.entity.Entity> event) {
        if (event.getObject() instanceof Player) {
            event.addCapability(MANA_CAPABILITY_ID, new ManaCapabilityProvider());
        }
    }

    @SubscribeEvent
    public void onPlayerClone(PlayerEvent.Clone event) {
        if (!event.isWasDeath()) {
            return;
        }
        event.getOriginal().getCapability(ManaCapabilities.MANA).ifPresent(oldStore -> {
            event.getEntity().getCapability(ManaCapabilities.MANA).ifPresent(newStore -> {
                newStore.setMana(oldStore.getMana());
                newStore.setWaterRank(oldStore.getWaterRank());
            });
        });
    }

    @SubscribeEvent
    public void onLivingTick(LivingEvent.LivingTickEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        if (player.level().isClientSide) {
            return;
        }
        LazyOptional<IManaStorage> capability = player.getCapability(ManaCapabilities.MANA);
        capability.ifPresent(mana -> {
            mana.regenerate(PASSIVE_REGEN_PER_TICK);
            if (player instanceof ServerPlayer serverPlayer && serverPlayer.tickCount % 10 == 0) {
                NetworkHandler.CHANNEL.send(
                        PacketDistributor.PLAYER.with(() -> serverPlayer),
                        new ManaSyncPacket(mana.getMana(), mana.getMaxMana())
                );
            }
        });
    }
}
