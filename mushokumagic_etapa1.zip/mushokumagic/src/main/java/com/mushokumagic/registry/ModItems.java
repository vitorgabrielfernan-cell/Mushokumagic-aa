package com.mushokumagic.registry;

import com.mushokumagic.MushokuMagicMod;
import com.mushokumagic.item.StaffItem;
import com.mushokumagic.magic.spell.WaterBallSpell;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Registro central de itens do mod. Novos cajados, armas e materiais das proximas
 * etapas (Eris, Sylphiette, Ruijerd...) entram aqui.
 */
public final class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MushokuMagicMod.MOD_ID);

    public static final RegistryObject<Item> WATER_STAFF = ITEMS.register("water_staff",
            () -> new StaffItem(
                    new Item.Properties()
                            .stacksTo(1)
                            .durability(250),
                    WaterBallSpell::new
            ));

    private ModItems() {
    }
}
