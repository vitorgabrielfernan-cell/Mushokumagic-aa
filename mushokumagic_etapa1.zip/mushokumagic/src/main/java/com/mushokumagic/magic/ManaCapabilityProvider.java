package com.mushokumagic.magic;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityProvider;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.util.INBTSerializable;
import net.minecraftforge.common.util.LazyOptional;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * Provedor Forge da capability de mana, usado para anexar ManaCapability a cada jogador
 * atraves do AttachCapabilitiesEvent registrado em ManaAttachEvent.
 */
public class ManaCapabilityProvider extends CapabilityProvider<ManaCapabilityProvider>
        implements ICapabilityProvider, INBTSerializable<CompoundTag> {

    private final ManaCapability backend = new ManaCapability();
    private final LazyOptional<IManaStorage> optional = LazyOptional.of(() -> backend);

    public ManaCapabilityProvider() {
        super(ManaCapabilityProvider.class);
    }

    @Nonnull
    @Override
    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> cap, @Nullable Direction side) {
        if (cap == ManaCapabilities.MANA) {
            return optional.cast();
        }
        return LazyOptional.empty();
    }

    @Override
    public CompoundTag serializeNBT() {
        return backend.serializeNBT();
    }

    @Override
    public void deserializeNBT(CompoundTag nbt) {
        backend.deserializeNBT(nbt);
    }

    public ManaCapability getBackend() {
        return backend;
    }
}
