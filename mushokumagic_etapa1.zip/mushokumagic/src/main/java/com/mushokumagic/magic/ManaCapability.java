package com.mushokumagic.magic;

import net.minecraft.nbt.CompoundTag;

/**
 * Armazena a mana do jogador e o nivel de dominio (rank) de cada elemento de magia.
 * Ranks seguem a escala oficial do anime: 0=F, 1=E, 2=D, 3=C, 4=B, 5=A, 6=S.
 */
public class ManaCapability implements IManaStorage {

    public static final float MAX_MANA_BASE = 100.0f;

    private float mana = MAX_MANA_BASE;
    private float maxMana = MAX_MANA_BASE;
    private int waterRank = 0;

    @Override
    public float getMana() {
        return mana;
    }

    @Override
    public float getMaxMana() {
        return maxMana;
    }

    @Override
    public void setMana(float value) {
        this.mana = Math.max(0.0f, Math.min(value, maxMana));
    }

    @Override
    public boolean consumeMana(float amount) {
        if (mana < amount) {
            return false;
        }
        mana -= amount;
        return true;
    }

    @Override
    public void regenerate(float amount) {
        setMana(mana + amount);
    }

    @Override
    public int getWaterRank() {
        return waterRank;
    }

    @Override
    public void setWaterRank(int rank) {
        this.waterRank = Math.max(0, Math.min(rank, 6));
    }

    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putFloat("Mana", mana);
        tag.putFloat("MaxMana", maxMana);
        tag.putInt("WaterRank", waterRank);
        return tag;
    }

    public void deserializeNBT(CompoundTag tag) {
        this.mana = tag.getFloat("Mana");
        this.maxMana = tag.contains("MaxMana") ? tag.getFloat("MaxMana") : MAX_MANA_BASE;
        this.waterRank = tag.getInt("WaterRank");
    }
}
