package com.mushokumagic.magic;

import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;

/**
 * Registro estatico da capability de mana. Usado por ManaAttachEvent e por qualquer
 * classe que precise ler/alterar a mana de uma entidade (feiticos, GUI, rede).
 */
public final class ManaCapabilities {

    public static final Capability<IManaStorage> MANA =
            CapabilityManager.get(new CapabilityToken<>() {});

    private ManaCapabilities() {
    }
}
