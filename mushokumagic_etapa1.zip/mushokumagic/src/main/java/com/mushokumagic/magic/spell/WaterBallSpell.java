package com.mushokumagic.magic.spell;

import com.mushokumagic.magic.IManaStorage;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerLevel;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;

/**
 * Water Ball - feitico de agua rank F/E conforme o anime: uma esfera de agua compacta
 * disparada em linha reta, causando dano de impacto no primeiro alvo atingido.
 *
 * Implementacao da Etapa 1: usa raytrace instantaneo (sem entidade de projetil propria
 * ainda) para garantir uma versao 100% funcional e testavel agora. Um projetil visual
 * com fisica propria entra na Etapa 2, junto dos feiticos de rank superior.
 */
public class WaterBallSpell implements Spell {

    private static final float MANA_COST = 8.0f;
    private static final int COOLDOWN_TICKS = 20; // 1 segundo
    private static final double RANGE = 16.0;
    private static final float DAMAGE = 4.0f; // 2 coracoes, equivalente a rank F/E

    private static final ConcurrentHashMap<UUID, Long> lastCastTick = new ConcurrentHashMap<>();

    @Override
    public String getName() {
        return "Water Ball";
    }

    @Override
    public float getManaCost() {
        return MANA_COST;
    }

    @Override
    public int getCooldownTicks() {
        return COOLDOWN_TICKS;
    }

    @Override
    public boolean tryCast(Level level, Player caster, IManaStorage mana) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return false;
        }

        long now = level.getGameTime();
        Long last = lastCastTick.get(caster.getUUID());
        if (last != null && now - last < COOLDOWN_TICKS) {
            caster.displayClientMessage(Component.translatable("message.mushokumagic.on_cooldown"), true);
            return false;
        }

        if (!mana.consumeMana(MANA_COST)) {
            return false;
        }

        lastCastTick.put(caster.getUUID(), now);

        Vec3 start = caster.getEyePosition();
        Vec3 look = caster.getLookAngle();
        Vec3 end = start.add(look.scale(RANGE));

        HitResult blockHit = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, caster));
        double maxDistance = blockHit.getType() != HitResult.Type.MISS
                ? start.distanceTo(blockHit.getLocation())
                : RANGE;

        Predicate<Entity> canHit = e -> e != caster && e.isAlive() && e instanceof LivingEntity;
        AABB searchBox = caster.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(1.0);
        List<Entity> candidates = level.getEntities(caster, searchBox, canHit);

        Entity target = null;
        double closest = maxDistance;
        for (Entity candidate : candidates) {
            AABB box = candidate.getBoundingBox().inflate(0.3);
            var optionalHit = box.clip(start, end);
            if (optionalHit.isPresent()) {
                double distance = start.distanceTo(optionalHit.get());
                if (distance < closest) {
                    closest = distance;
                    target = candidate;
                }
            }
        }

        Vec3 impactPoint = start.add(look.scale(closest));

        if (target instanceof LivingEntity livingTarget) {
            livingTarget.hurt(level.damageSources().magic(), DAMAGE);
            livingTarget.invulnerableTime = 0;
        }

        spawnTravelParticles(serverLevel, start, impactPoint);
        serverLevel.playSound(null, caster.getX(), caster.getY(), caster.getZ(),
                SoundEvents.PLAYER_SPLASH, SoundSource.PLAYERS, 1.0f, 1.0f);

        return true;
    }

    private void spawnTravelParticles(ServerLevel serverLevel, Vec3 start, Vec3 end) {
        double distance = start.distanceTo(end);
        int steps = Math.max(1, (int) (distance * 4));
        for (int i = 0; i <= steps; i++) {
            double t = (double) i / steps;
            Vec3 point = start.lerp(end, t);
            serverLevel.sendParticles(ParticleTypes.SPLASH, point.x, point.y, point.z, 2, 0.05, 0.05, 0.05, 0.0);
            serverLevel.sendParticles(ParticleTypes.BUBBLE, point.x, point.y, point.z, 1, 0.05, 0.05, 0.05, 0.01);
        }
    }
}
