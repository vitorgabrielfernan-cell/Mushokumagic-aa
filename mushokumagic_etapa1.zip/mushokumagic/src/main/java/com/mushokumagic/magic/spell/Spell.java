package com.mushokumagic.magic.spell;

import com.mushokumagic.magic.IManaStorage;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Contrato comum de todo feitico do mod. Cada elemento (Agua, Fogo, Terra, Vento, Cura,
 * Eletrica) tera suas proprias classes implementando esta interface nas proximas etapas.
 */
public interface Spell {

    /** Nome oficial do feitico, conforme o anime (ex: "Water Ball"). */
    String getName();

    /** Custo de mana para lancar o feitico nesta etapa de desenvolvimento. */
    float getManaCost();

    /** Tempo de recarga em ticks (20 ticks = 1 segundo). */
    int getCooldownTicks();

    /**
     * Tenta lancar o feitico: verifica e consome mana, aplica efeito, som e particulas.
     * Retorna true se o feitico foi efetivamente lancado.
     */
    boolean tryCast(Level level, Player caster, IManaStorage mana);
}
