package com.mushokumagic.magic;

/**
 * Interface da capability de mana. Permite trocar a implementacao (ex: criaturas com
 * regras diferentes) sem alterar o codigo que consome mana (feiticos, GUI, rede).
 */
public interface IManaStorage {

    float getMana();

    float getMaxMana();

    void setMana(float value);

    boolean consumeMana(float amount);

    void regenerate(float amount);

    int getWaterRank();

    void setWaterRank(int rank);
}
