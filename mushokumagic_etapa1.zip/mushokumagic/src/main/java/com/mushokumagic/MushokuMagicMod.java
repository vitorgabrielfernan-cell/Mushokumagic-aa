package com.mushokumagic;

import com.mushokumagic.event.ManaAttachEvent;
import com.mushokumagic.network.NetworkHandler;
import com.mushokumagic.registry.ModItems;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Classe principal do mod Mushoku Magic.
 * Etapa 1: registra itens base e inicializa o sistema de mana (Capability) e a rede
 * de sincronizacao cliente/servidor necessaria para a magia de Agua funcionar.
 */
@Mod(MushokuMagicMod.MOD_ID)
public class MushokuMagicMod {

    public static final String MOD_ID = "mushokumagic";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    public MushokuMagicMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModItems.ITEMS.register(modEventBus);

        modEventBus.addListener(NetworkHandler::register);

        MinecraftForge.EVENT_BUS.register(new ManaAttachEvent());

        LOGGER.info("Mushoku Magic: etapa 1 carregada (mana + magia de Agua).");
    }
}
