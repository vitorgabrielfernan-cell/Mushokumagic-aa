package com.mushokumagic.client;

/**
 * Cache do lado cliente com a ultima mana sincronizada do jogador local.
 * Sera consumido pela GUI de habilidades planejada para a Etapa 5.
 */
public final class ClientManaCache {

    private static float mana = 0.0f;
    private static float maxMana = 100.0f;

    public static void update(float newMana, float newMaxMana) {
        mana = newMana;
        maxMana = newMaxMana;
    }

    public static float getMana() {
        return mana;
    }

    public static float getMaxMana() {
        return maxMana;
    }

    private ClientManaCache() {
    }
}
