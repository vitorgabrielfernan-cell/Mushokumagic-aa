package com.mushokumagic.network;

import com.mushokumagic.MushokuMagicMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;

/**
 * Canal de rede do mod. Etapa 1 registra apenas ManaSyncPacket (servidor -> cliente),
 * usado para manter o cliente informado da mana atual (base para a GUI da Etapa 5).
 */
public final class NetworkHandler {

    private static final String PROTOCOL_VERSION = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MushokuMagicMod.MOD_ID, "main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    private static int packetId = 0;

    public static void register(FMLCommonSetupEvent event) {
        CHANNEL.registerMessage(
                packetId++,
                ManaSyncPacket.class,
                ManaSyncPacket::encode,
                ManaSyncPacket::decode,
                ManaSyncPacket::handle
        );
    }

    private NetworkHandler() {
    }
}
