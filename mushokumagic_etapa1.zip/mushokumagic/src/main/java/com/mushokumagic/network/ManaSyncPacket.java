package com.mushokumagic.network;

import com.mushokumagic.client.ClientManaCache;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Pacote servidor -> cliente com o valor atual de mana do jogador.
 * O cliente armazena o valor em ClientManaCache para uso futuro na GUI (Etapa 5).
 */
public class ManaSyncPacket {

    private final float mana;
    private final float maxMana;

    public ManaSyncPacket(float mana, float maxMana) {
        this.mana = mana;
        this.maxMana = maxMana;
    }

    public static void encode(ManaSyncPacket packet, FriendlyByteBuf buffer) {
        buffer.writeFloat(packet.mana);
        buffer.writeFloat(packet.maxMana);
    }

    public static ManaSyncPacket decode(FriendlyByteBuf buffer) {
        return new ManaSyncPacket(buffer.readFloat(), buffer.readFloat());
    }

    public static void handle(ManaSyncPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> ClientManaCache.update(packet.mana, packet.maxMana));
        context.setPacketHandled(true);
    }
}
